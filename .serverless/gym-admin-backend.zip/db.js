const mongoose = require("mongoose");



class DataBaseManagment {
    constructor() {
        this.db = '';
    }

    static establishConnection() {
        // mongodb+srv://admin:<password>@cluster0.dfyku.mongodb.net/myFirstDatabase?retryWrites=true&w=majority
        mongoose.connect("mongodb+srv://admin:admin1234@cluster0.dfyku.mongodb.net/gym_admin?retryWrites=true&w=majority", { useNewUrlParser: true }, (err, db) => {
            // console.log(db)
            console.log(err);
            this.db = db;
            var collection = db.collection("user");
            // console.log(collection);
            console.log("connected to DB")
        })

    }

    static closeConnection(){
        mongoose.connection.close()
    }

    static getDb() {
        return this.db;
    }
}


module.exports = DataBaseManagment;
