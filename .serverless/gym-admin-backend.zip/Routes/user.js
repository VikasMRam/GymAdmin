const express = require("express");
const router = express.Router();
const userModel = require("../Models/user");

const Db = require("../db");

router.post("/createuser", (req, res) => {
  const usermodel = new userModel({
    firstName: req.body.firstName,
    middleName: req.body.middleName,
    lastName: req.body.lastName,
    phone: req.body.phone,
    gender: req.body.gender,
    age: req.body.age,
    weight: req.body.weight,
    height: req.body.height,
    additional_details: req.body.additional_details,
    membershipDetails: req.body.membershipDetails,
  });
  usermodel["userId"] = usermodel["_id"];
  usermodel
    .save()
    .then((data) => {
      res.json(data);
    })
    .catch((err) => {
      console.log(err);
    });
});

router.get("/getUserById", (req, res) => {
  let userId = req.query.userId;
  let db = Db.db;
  db.collection("users")
    .findOne({ userId: userId })
    .then((response) => {
      res.json(response);
    });
});

router.post("/updateUser", (req, res) => {
  const usermodel = {
    firstName: req.body.firstName,
    middleName: req.body.middleName,
    lastName: req.body.lastName,
    phone: req.body.phone,
    gender: req.body.gender,
    age: req.body.age,
    weight: req.body.weight,
    height: req.body.height,
    additional_details: req.body.additional_details,
    membershipDetails: req.body.membershipDetails,
  };
  let userId = req["body"]["userId"];
  let db = Db.db;
  db.collection("users")
    .updateOne({ userId: userId }, { $set: usermodel }, { upsert: false })
    .then((response) => {
      res.json(response);
    });
});


module.exports = router;
