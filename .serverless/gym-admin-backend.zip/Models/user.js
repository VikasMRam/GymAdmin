const mongoose = require("mongoose");

const userScheme = mongoose.Schema({
  firstName: String,
  middleName: String,
  lastName: String,
  phone: String,
  email: String,
  gender : String,
  age: Number,
  weight: Number,
  height: Number,
  additional_details: String,
  membershipDetails : Array,
  userId : String
});

module.exports = mongoose.model("users", userScheme);
